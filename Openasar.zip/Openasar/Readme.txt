OpenAsar is an discord plugin to make discord to be super light and small.
Simply just run the bat and ur done.

- Eltxzu